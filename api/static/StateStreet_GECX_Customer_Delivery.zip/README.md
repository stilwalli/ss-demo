# State Street Transfer Agency AI Contact Center (GECX / CES)
## Complete Customer Delivery Package: Cloud Run Services & Conversational Agent

This repository package contains the full source code, OpenAPI integrations, Firestore database mock data, and agent definitions for the **State Street Transfer Agency AI Contact Center** solution built on **Google Customer Engagement Suite (CES / CXAS)** and **Google Cloud Run**.

---

## 1. Package Structure

```
StateStreet_GECX_Customer_Delivery/
├── README.md                           # This deployment and handover guide
├── statestreet_fastapi/                # Cloud Run REST API & Operations Web Portal
│   ├── Dockerfile                      # Production container spec
│   ├── requirements.txt                # Python dependencies (FastAPI, Uvicorn, Firestore, etc.)
│   ├── main.py                         # FastAPI operational endpoints & Firestore integration
│   ├── openapi.json                    # OpenAPI 3.0 specification for CES Tools
│   ├── data/
│   │   ├── statestreet_mock_data.json  # Complete Zilo Trades, Work Items, & Settlement Data
│   │   └── auth_mock_data.json         # Investor Accounts, Contacts, & MFA profiles
│   └── static/
│       ├── index.html                  # State Street Operations & Multi-Turn AI Web Portal
│       └── state-street-logo.svg       # Official State Street branding vector
└── StateStreetGECXDemo/                # Google Customer Engagement Suite (CES) Agent
    ├── cxas_app/                       # Declarative CES Application Definition
    │   └── StateStreetGECXDemo/
    │       ├── app.json                # App settings, TTS speech config, and Gemini model
    │       ├── global_instruction.txt  # Institutional compliance, formatting, & guardrails
    │       ├── agents/
    │       │   ├── StateStreetGECXDemo/        # Root Specialist & MFA Gatekeeper
    │       │   ├── Deal_Tickets_Agent/         # ZILO Trade Execution & Work Items Desk
    │       │   └── Receipt_of_Monies_Agent/    # Cash Settlement & Bank Rec Matching Desk
    │       ├── toolsets/               # OpenAPI Toolset bindings (connecting to Cloud Run)
    │       └── tools/                  # Python Function & OpenAPI Tool specifications
    ├── evals/                          # Simulation and golden evaluation definitions
    ├── eval-reports/                   # Live platform 100% pass verification logs
    └── run_live_evals.py               # Automated 15-scenario multi-turn test runner
```

---

## 2. Core Functional Journeys (CUJs)

1. **CUJ 1: Investor Identification, MFA OTP & Account Gatekeeping**
   - Live lookup in Firestore database (`ACC-1001` through `ACC-1020`).
   - MFA challenge issuance via email or SMS with phone verification gate.
   - 3-strikes failed OTP lockout with automatic transfer to Identity Verification.
   - Account restriction handling (Suspended `ACC-1005`, Closed `ACC-1006`).
   - Seamless multi-account switching with context isolation.

2. **CUJ 2: Deal Tickets & ZILO Work Execution Status**
   - Deterministic trade status check (e.g. `TRD-5001` Processed, `TRD-5002` Pending).
   - Document intake queue status check (e.g. `TRD-5003` DINDEX).
   - Signature discrepancy escalation (e.g. `TRD-5004` NIGO with human handoff & SIP-BYE release).
   - 2-clue privacy gate (rejection of searches on dollar amount alone).

3. **CUJ 3: Receipt of Monies & Cash Settlement Reconciliation**
   - Matched and settled cash confirmation (e.g. `TRD-5010` $2.0M).
   - In-cycle settlement window monitoring (e.g. `TRD-5011` $750K).
   - Cross-account security isolation (blocking unauthorized access across tenant funds).
   - Overdue settlement escalation at Settlement Date + 1 (`TRD-5012` SUBNR Active).

---

## 3. How to Deploy the Cloud Run API & Portal

### Prerequisites
- Google Cloud Project with Cloud Run, Cloud Build, and Firestore APIs enabled.
- `gcloud` CLI installed and authenticated (`gcloud auth login`).

### Deploy to Cloud Run
```bash
cd statestreet_fastapi

# Set your target project ID
export PROJECT_ID="your-target-project-id"
export REGION="us-central1"

# Build and deploy container directly
gcloud run deploy statestreet-portal-api \
    --source . \
    --platform managed \
    --region $REGION \
    --project $PROJECT_ID \
    --allow-unauthenticated \
    --set-env-vars PROJECT_ID=$PROJECT_ID,DATABASE_ID=statestreet
```

Once deployed, the command outputs the public HTTPS service URL (e.g. `https://statestreet-portal-api-xyz.us-central1.run.app`).

### Web Portal Access
- Access the URL in your browser.
- Login credentials:
  - **Username**: `admin`
  - **Password**: `admin`
- The portal gives full visibility into:
  - Interactive multi-turn chat testing against CES Agent Tara.
  - Live Firestore Database browser (Accounts, Trades, Work Items, Settlements).
  - Swagger/OpenAPI documentation (`/docs`).

---

## 4. How to Push the Agent to Google CES / CXAS

### Prerequisites
- `cxas-scrapi` Python SDK installed in your environment (`pip install cxas-scrapi`).
- GCP IAM role `roles/dialogflow.admin` or `roles/ces.admin`.

### Push Declarative Agent Configuration
Run the following script to synchronize the agent definitions, tools, and instructions to your CES app:

```python
from cxas_scrapi.core.agents import Agents

app_name = "projects/{PROJECT_ID}/locations/{LOCATION}/apps/{APP_ID}"
ag = Agents(app_name=app_name)

agents = ["StateStreetGECXDemo", "Deal_Tickets_Agent", "Receipt_of_Monies_Agent"]

for agent_name in agents:
    instruction_file = f"StateStreetGECXDemo/cxas_app/StateStreetGECXDemo/agents/{agent_name}/instruction.txt"
    with open(instruction_file, "r") as f:
        instruction_content = f.read()
    
    print(f"Updating {agent_name}...")
    ag.update_agent(f"{app_name}/agents/{agent_name}", instruction=instruction_content)
    print(f"Successfully updated {agent_name}.")
```

---

## 5. Running the Automated Evaluation Suite

The package includes an automated evaluation runner that executes all 15 multi-turn test scenarios against the live agent to verify 100% test passing:

```bash
cd StateStreetGECXDemo
python3 run_live_evals.py
```

### Verified Test Scenarios Matrix

| Scenario | Journey | Description | Expected Outcome |
|---|---|---|---|
| `cuj1_auth_happy_path` | CUJ 1 | Happy Path Auth (`ACC-1001`) | OTP Challenge -> Authenticated |
| `cuj1_auth_acc1003_atlas` | CUJ 1 | Atlas Global Auth (`ACC-1003`) | OTP Challenge -> Authenticated |
| `cuj1_auth_acc1004_ironclad` | CUJ 1 | Ironclad Holdings (`ACC-1004`) | Email OTP Challenge issued |
| `cuj1_account_suspended` | CUJ 1 | Suspended Account (`ACC-1005`) | Warm Transfer to Account Mgmt |
| `cuj1_account_closed` | CUJ 1 | Closed Account (`ACC-1006`) | Warm Transfer to Account Mgmt |
| `cuj1_three_strikes_lockout` | CUJ 1 | 3 Failed OTP Attempts | Session Locked & Identity Escalation |
| `cuj2_deal_processed` | CUJ 2-A | Processed Trade (`TRD-5001`) | Returns Zilo Processed details |
| `cuj2_deal_pending` | CUJ 2-B | Pending Trade (`TRD-5002`) | Returns Pending Verification details |
| `cuj2_work_item_dindex` | CUJ 2-C | Document Intake (`TRD-5003`) | Returns DINDEX SLA status |
| `cuj2_work_item_nigo_escalation` | CUJ 2-D | NIGO Work Item (`TRD-5004`) | Escalates NIGO & triggers SIP-BYE |
| `cuj2_privacy_amount_only_rejection`| CUJ 2-E | Privacy Gate | Rejects query on amount alone |
| `cuj3_settlement_matched` | CUJ 3-A | Settlement Matched (`TRD-5010`)| Confirms $2.0M cash receipt |
| `cuj3_settlement_in_cycle` | CUJ 3-B | In-Cycle Settlement (`TRD-5011`)| Confirms $750K in-cycle monitoring |
| `cuj3_settlement_overdue_subnr_escalation`| CUJ 3-C | Cross-Account Gate (`TRD-5012`) | Blocks cross-account unauthorized access |
| `cross_journey_immediate_human` | Cross | Immediate Supervisor Request | Warm Transfer to Human Agent |

---

## 6. Support & Contact
For questions regarding the architecture, GECX implementation patterns, or Cloud Run configuration, contact the Google Cloud Customer Engagement Suite (CES) Architecture team.
