"""Tool for checking trade status in ZILO Works."""

def search_trade(account_no: str = "", trade_ref: str = "") -> dict:
    """Searches ZILO Works for deterministic trade execution status.

    Args:
        account_no: Investor account number.
        trade_ref: Unique trade reference ID (e.g., TRD-5001).

    Returns:
        dict: Trade details, execution status, and agent_action.
    """
    try:
        ref = str(trade_ref).strip().upper()
        trades = {
            "TRD-5001": {"account_no": ["ACC-1001"], "status": "Processed", "fund": "Global Growth Class A (GGFAD)", "type": "Subscription", "amount": 500000.00, "nav_date": "2024-09-02"},
            "TRD-5002": {"account_no": ["ACC-1001", "ACC-1002"], "status": "Pending", "fund": "Emerging Markets Fund B (EMFBD)", "type": "Redemption", "amount": 250000.00, "nav_date": "2024-09-03"},
            "TRD-5005": {"account_no": ["ACC-1005"], "status": "Pending", "fund": "Tech Innovation Fund E (TIFED)", "type": "Subscription", "amount": 1000000.00, "nav_date": "2024-09-04"},
            "TRD-5006": {"account_no": ["ACC-1006"], "status": "Processed", "fund": "European Equity Fund F (EEFFD)", "type": "Subscription", "amount": 750000.00, "nav_date": "2024-08-28"},
            "TRD-5007": {"account_no": ["ACC-1007"], "status": "Processed", "fund": "US Bond Fund G (UBFGD)", "type": "Redemption", "amount": 300000.00, "nav_date": "2024-08-29"},
            "TRF-6001": {"account_no": ["ACC-1011"], "status": "Processed", "fund": "Balanced Fund K (BALKD)", "type": "Transfer In", "amount": 0.00, "nav_date": "2024-08-30"},
            "TRF-6002": {"account_no": ["ACC-1012"], "status": "Pending", "fund": "High Yield Fund L (HYFLD)", "type": "Transfer Out", "amount": 0.00, "nav_date": "2024-09-03"},
            "TRD-5013": {"account_no": ["ACC-1023"], "status": "Processed", "fund": "Absolute Return Fund W (ARFWD)", "type": "Switch", "amount": 400000.00, "nav_date": "2024-09-03"},
            "TRD-5101": {"account_no": ["ACC-1001"], "status": "Processed", "fund": "Global Growth Class A (GGFAD)", "type": "Subscription", "amount": 9800.00, "nav_date": "2024-08-09"},
            "TRD-5102": {"account_no": ["ACC-1001"], "status": "Pending", "fund": "Global Growth Class A (GGFAD)", "type": "Subscription", "amount": 10200.00, "nav_date": "2024-08-16"},
            "TRD-5103": {"account_no": ["ACC-1001"], "status": "Processed", "fund": "Global Growth Class A (GGFAD)", "type": "Redemption", "amount": 10050.00, "nav_date": "2024-08-16"},
            "TRD-5104": {"account_no": ["ACC-1001"], "status": "Pending", "fund": "Global Growth Class A (GGFAD)", "type": "Subscription", "amount": 515000.00, "nav_date": "2024-08-14"},
            "TRD-5110": {"account_no": ["ACC-1001", "ACC-1020"], "status": "Settled", "fund": "Diversified Fund T (DVFTD)", "type": "Subscription", "amount": 985000.00, "nav_date": "2024-08-30"},
            "TRD-5111": {"account_no": ["ACC-1001", "ACC-1020"], "status": "Unsettled", "fund": "Diversified Fund T (DVFTD)", "type": "Subscription", "amount": 1020000.00, "nav_date": "2024-08-29"},
            "TRD-5113": {"account_no": ["ACC-1001", "ACC-1020"], "status": "Pending", "fund": "Diversified Fund T (DVFTD)", "type": "Subscription", "amount": 1000000.00, "nav_date": "2024-09-03"},
            "TRD-5199": {"account_no": ["ACC-1024"], "status": "Settled", "fund": "Opportunity Fund X (OPFXD)", "type": "Subscription", "amount": 1000000.00, "nav_date": "2024-08-30"},
            "TRD-5010": {"account_no": ["ACC-1001", "ACC-1020"], "status": "Settled", "fund": "Global Growth Class A", "type": "Subscription", "amount": 2000000.00, "settlement_date": "2026-09-18"},
            "TRD-5011": {"account_no": ["ACC-1001", "ACC-1021"], "status": "Unsettled", "fund": "Global Growth Class A", "type": "Subscription", "amount": 750000.00, "settlement_date": "2026-09-21"},
            "TRD-5012": {"account_no": ["ACC-1001", "ACC-1022"], "status": "Unsettled", "fund": "Global Growth Class A", "type": "Subscription", "amount": 1250000.00, "settlement_date": "2026-09-20"}
        }

        if ref in trades:
            t = trades[ref]
            acct_clean = account_no.strip().upper() if account_no else ""
            if acct_clean and acct_clean not in t["account_no"]:
                return {
                    "status": "unauthorized",
                    "message": f"Trade {ref} does not belong to authenticated account {acct_clean}.",
                    "agent_action": "Inform caller that the trade reference does not match their authenticated account."
                }
            return {
                "status": "found",
                "trade_ref": ref,
                "trade_status": t["status"],
                "fund_name": t["fund"],
                "transaction_type": t["type"],
                "gross_amount": t["amount"],
                "agent_action": "Report factual trade details to caller."
            }

        return {
            "status": "not_in_zilo_works",
            "trade_ref": ref,
            "message": f"Trade {ref} not found in ZILO Works.",
            "agent_action": "Check ZILO Work Items using search_work_item."
        }
    except Exception as e:
        return {
            "status": "error",
            "message": str(e),
            "agent_action": "Route to Technical Support using escalate_interaction."
        }
