"""Tool for comprehensive settlement and monies received inquiry."""

def execute_settlement_inquiry(account_no: str = "", trade_ref: str = "") -> dict:
    """Comprehensive settlement evaluation across ZILO Trades, Bank Rec, and SUBNR.

    Args:
        account_no: Investor account number.
        trade_ref: Unique trade reference ID.

    Returns:
        dict: Comprehensive settlement outcome and agent_action.
    """
    try:
        ref = str(trade_ref).strip().upper()
        settlement_db = {
            "TRD-5010": {
                "account_no": ["ACC-1001", "ACC-1020"],
                "status": "settled_and_matched",
                "zilo_status": "Settled",
                "bank_rec_status": "Matched",
                "subnr": "No",
                "amount": 2000000.00,
                "currency": "USD",
                "message": "Monies received and matched in full. Trade settled.",
                "agent_action": "Inform caller that full settlement monies of $2,000,000.00 are received and posted."
            },
            "TRD-5011": {
                "account_no": ["ACC-1001", "ACC-1021"],
                "status": "unsettled_in_cycle",
                "zilo_status": "Unsettled",
                "bank_rec_status": "Unmatched",
                "subnr": "No",
                "amount": 750000.00,
                "currency": "USD",
                "message": "Trade is currently within normal settlement window (SD).",
                "agent_action": "Inform caller that settlement is in-cycle and monitoring will continue."
            },
            "TRD-5012": {
                "account_no": ["ACC-1001", "ACC-1022"],
                "status": "overdue_subnr_escalation",
                "zilo_status": "Unsettled",
                "bank_rec_status": "Unmatched",
                "subnr": "Yes",
                "amount": 1250000.00,
                "currency": "USD",
                "message": "Monies overdue at Settlement Date + 1 with SUBNR flag active.",
                "agent_action": "Immediately escalate to Cash Management queue via escalate_interaction."
            },
            "TRD-5110": {
                "account_no": ["ACC-1001", "ACC-1020"],
                "status": "settled_and_matched",
                "zilo_status": "Settled",
                "bank_rec_status": "Matched",
                "subnr": "No",
                "amount": 985000.00,
                "currency": "USD",
                "message": "Full settlement monies of $985,000.00 received and matched.",
                "agent_action": "Inform caller trade is settled and matched."
            },
            "TRD-5111": {
                "account_no": ["ACC-1001", "ACC-1020"],
                "status": "unsettled_in_cycle",
                "zilo_status": "Unsettled",
                "bank_rec_status": "Unmatched",
                "subnr": "No",
                "amount": 1020000.00,
                "currency": "USD",
                "message": "Trade is currently unsettled and unmatched in normal cycle.",
                "agent_action": "Inform caller settlement is in-cycle."
            },
            "TRD-5113": {
                "account_no": ["ACC-1001", "ACC-1020"],
                "status": "unsettled_in_cycle",
                "zilo_status": "Pending",
                "bank_rec_status": "Unmatched",
                "subnr": "No",
                "amount": 1000000.00,
                "currency": "USD",
                "message": "Trade is pending settlement in normal cycle.",
                "agent_action": "Inform caller settlement is pending."
            },
            "TRD-5199": {
                "account_no": ["ACC-1024"],
                "status": "settled_and_matched",
                "zilo_status": "Settled",
                "bank_rec_status": "Matched",
                "subnr": "No",
                "amount": 1000000.00,
                "currency": "EUR",
                "message": "Settlement record for Opportunity Fund X.",
                "agent_action": "Inform caller trade is settled."
            }
        }

        if ref in settlement_db:
            s = settlement_db[ref]
            acct_clean = account_no.strip().upper() if account_no else ""
            if acct_clean and acct_clean not in s["account_no"]:
                return {
                    "status": "unauthorized",
                    "message": f"Settlement record {ref} does not belong to authenticated account {acct_clean}.",
                    "agent_action": "Inform caller that settlement records do not match this account."
                }
            return {
                "status": s["status"],
                "trade_ref": ref,
                "zilo_status": s["zilo_status"],
                "bank_rec_status": s["bank_rec_status"],
                "subnr": s["subnr"],
                "amount": s["amount"],
                "message": s["message"],
                "agent_action": s["agent_action"]
            }

        return {
            "status": "not_found",
            "message": f"Settlement record not found for {ref}.",
            "agent_action": "Verify trade reference or escalate to Investor Services."
        }
    except Exception as e:
        return {
            "status": "error",
            "message": str(e),
            "agent_action": "Route to Technical Support using escalate_interaction."
        }
