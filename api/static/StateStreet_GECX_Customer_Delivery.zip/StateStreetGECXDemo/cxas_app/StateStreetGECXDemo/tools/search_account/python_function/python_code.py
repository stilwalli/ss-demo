"""Tool for looking up account details in ZILO client master."""

def search_account(account_no: str = "") -> dict:
    """Retrieves account details and investor profile from the ZILO client master.

    Args:
        account_no: Unique investor account number (e.g., ACC-1001).

    Returns:
        dict: Account details, status, investor profile, and agent_action.
    """
    try:
        acct = str(account_no).strip().upper()
        if not acct:
            return {
                "status": "error",
                "message": "Account number is required.",
                "agent_action": "Ask caller to provide their account number."
            }

        # Complete mock mapping from GECX_Mock_Data_Authentication_1
        known = {
            "ACC-1001": {
                "auth_profile_id": "AUTH-2001",
                "name": "Apex Global Growth Fund",
                "investor": "Sarah Jenkins",
                "email": "s.jenkins@apexglobal.com",
                "phone": "+1-617-555-0142",
                "phone_verified": "Yes",
                "status": "Active",
                "allowed_otp_route": "Email OTP; SMS OTP",
                "eligibility_note": "Eligible"
            },
            "ACC-1002": {
                "auth_profile_id": "AUTH-2002",
                "name": "Beacon Hill Capital",
                "investor": "David Ross",
                "email": "d.ross@beaconhillcap.com",
                "phone": "+1-617-555-0199",
                "phone_verified": "Yes",
                "status": "Active",
                "allowed_otp_route": "Email OTP; SMS OTP",
                "eligibility_note": "Eligible"
            },
            "ACC-1003": {
                "auth_profile_id": "AUTH-2003",
                "name": "Atlas Global Investors",
                "investor": "Marcus Vance",
                "email": "settle@atlasglobal.example",
                "phone": "+35315550103",
                "phone_verified": "Yes",
                "status": "Active",
                "allowed_otp_route": "Email OTP; SMS OTP",
                "eligibility_note": "Eligible"
            },
            "ACC-1004": {
                "auth_profile_id": "AUTH-2004",
                "name": "Ironclad Holdings",
                "investor": "Rachel Vance",
                "email": "ops@ironclad.example",
                "phone": "+35315550104",
                "phone_verified": "No",
                "status": "Active",
                "allowed_otp_route": "Email OTP",
                "eligibility_note": "Voice not eligible"
            },
            "ACC-1005": {
                "auth_profile_id": "AUTH-2005",
                "name": "Highland Institutional",
                "investor": "Thomas Wright",
                "email": "t.wright@highlandinst.com",
                "phone": "+1-617-555-0322",
                "phone_verified": "Yes",
                "status": "Suspended",
                "allowed_otp_route": "None",
                "eligibility_note": "Account Management"
            },
            "ACC-1006": {
                "auth_profile_id": "AUTH-2006",
                "name": "Vanguard Horizon Trust",
                "investor": "Elena Rostova",
                "email": "e.rostova@vanguardhorizon.com",
                "phone": "+1-617-555-0388",
                "phone_verified": "Yes",
                "status": "Closed",
                "allowed_otp_route": "None",
                "eligibility_note": "Account Management"
            },
            "ACC-1007": {
                "auth_profile_id": "AUTH-2007",
                "name": "Security Test Fund",
                "investor": "Alex Mercer",
                "email": "security@test.example",
                "phone": "+35315550107",
                "phone_verified": "Yes",
                "status": "Active",
                "allowed_otp_route": "Email OTP; SMS OTP",
                "eligibility_note": "Security edge case"
            }
        }

        if acct in known:
            info = known[acct]
            if info["status"] in ["Suspended", "Closed"]:
                return {
                    "status": "restricted",
                    "account_no": acct,
                    "auth_profile_id": info["auth_profile_id"],
                    "account_status": info["status"],
                    "allowed_otp_route": info["allowed_otp_route"],
                    "message": f"Account {acct} is {info['status']}.",
                    "agent_action": "Route immediately to Account Management queue using escalate_interaction."
                }
            return {
                "status": "success",
                "account_no": acct,
                "auth_profile_id": info["auth_profile_id"],
                "account_name": info["name"],
                "investor_name": info["investor"],
                "investor_email": info["email"],
                "investor_phone": info["phone"],
                "phone_verified": info["phone_verified"],
                "allowed_otp_route": info["allowed_otp_route"],
                "account_status": info["status"],
                "agent_action": "If on voice channel and phone_verified is No, route to Identity Verification. Otherwise proceed with OTP challenge using issue_otp_challenge."
            }

        return {
            "status": "not_found",
            "message": f"Account {acct} not found in ZILO master.",
            "agent_action": "Inquire if caller has another account number or route to Identity Verification."
        }
    except Exception as e:
        return {
            "status": "error",
            "message": str(e),
            "agent_action": "Route to Technical Support using escalate_interaction."
        }
