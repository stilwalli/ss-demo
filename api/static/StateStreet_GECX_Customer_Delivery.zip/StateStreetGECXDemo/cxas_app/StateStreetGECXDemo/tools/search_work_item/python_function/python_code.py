"""Tool for checking work items in ZILO Work Items."""

def search_work_item(account_no: str = "", trade_ref: str = "") -> dict:
    """Searches ZILO Work Items for document indexing (DINDEX) or NIGO exceptions.

    Args:
        account_no: Investor account number.
        trade_ref: Unique trade reference ID (e.g., TRD-5003).

    Returns:
        dict: Work item status, exception type, and agent_action.
    """
    try:
        ref = str(trade_ref).strip().upper()
        work_items = {
            "TRD-5003": {"account_no": ["ACC-1001", "ACC-1003"], "status": "DINDEX", "queue": "Document Indexing", "sla": "Same Day 17:00 ET", "message": "Trade document is currently in Document Indexing queue for intake."},
            "TRD-5004": {"account_no": ["ACC-1001", "ACC-1004"], "status": "NIGO", "queue": "Exception Review", "nigo_reason": "Signature Discrepancy", "action_needed": "Authorized signatory signature verification required", "message": "Trade is flagged Not In Good Order due to signature discrepancy."},
            "TRF-6003": {"account_no": ["ACC-1013"], "status": "NIGO", "queue": "DEALING", "nigo_reason": "Source account details incomplete (missing IBAN/BIC)", "action_needed": "Provide valid IBAN and BIC", "message": "Transfer is flagged NIGO due to incomplete account details."},
            "TRF-6004": {"account_no": ["ACC-1014"], "status": "DINDEX", "queue": "DEALING", "sla": "Same Day 17:00 ET", "message": "Transfer instruction is in Document Indexing queue pending compliance checks."},
            "AUD-7001": {"account_no": ["ACC-1015"], "status": "AUDIT", "queue": "ENQUIRY", "sla": "24h SLA", "message": "PwC Annual Audit request in progress."},
            "AUD-7002": {"account_no": ["ACC-1016"], "status": "AUDIT", "queue": "ENQUIRY", "sla": "24h SLA", "message": "Deloitte Audit confirmation in progress."},
            "AUD-7003": {"account_no": ["ACC-1017"], "status": "REJECTED", "queue": "ENQUIRY", "nigo_reason": "Auditor not authorized on account", "action_needed": "Submit authority letter", "message": "Audit request rejected: unauthorized auditor."},
            "WI-8001": {"account_no": ["ACC-1018"], "status": "DISTLIST", "queue": "MISC", "sla": "Standard SLA", "message": "Distribution list update request in progress."},
            "WI-8002": {"account_no": ["ACC-1019"], "status": "REJECTED", "queue": "QINVSERV", "nigo_reason": "Sender not authorized on account", "action_needed": "Submit authorized signatory request", "message": "Distribution update rejected: unauthorized sender."},
            "TRD-5015": {"account_no": ["ACC-1025"], "status": "DINDEX", "queue": "DEALING", "sla": "Same Day 17:00 ET", "message": "Switch instruction pending good order checks."},
            "TRD-5115": {"account_no": ["ACC-1001"], "status": "DINDEX", "queue": "DEALING", "sla": "Same Day 17:00 ET", "message": "Candidate subscription in Document Indexing queue."},
            "TRD-5116": {"account_no": ["ACC-1001"], "status": "NIGO", "queue": "DEALING", "nigo_reason": "Missing authorized signature", "action_needed": "Authorized signatory signature required", "message": "Candidate redemption flagged NIGO due to missing signature."}
        }

        if ref in work_items:
            w = work_items[ref]
            acct_clean = account_no.strip().upper() if account_no else ""
            if acct_clean and acct_clean not in w["account_no"]:
                return {
                    "status": "unauthorized",
                    "message": f"Work item {ref} does not belong to authenticated account {acct_clean}.",
                    "agent_action": "Inform caller that the work item reference does not match their authenticated account."
                }
            if w["status"] == "DINDEX":
                return {
                    "status": "found",
                    "trade_ref": ref,
                    "work_item_status": "DINDEX",
                    "queue_name": w["queue"],
                    "sla": w.get("sla", "Same Day 17:00 ET"),
                    "message": w["message"],
                    "agent_action": f"Inform caller document is indexing with SLA of {w.get('sla', 'Same Day 17:00 ET')}."
                }
            elif w["status"] in ["NIGO", "REJECTED"]:
                return {
                    "status": "found",
                    "trade_ref": ref,
                    "work_item_status": w["status"],
                    "nigo_reason": w["nigo_reason"],
                    "action_needed": w["action_needed"],
                    "message": w["message"],
                    "agent_action": "Route to Investor Services (Human) using escalate_interaction."
                }
            else:
                return {
                    "status": "found",
                    "trade_ref": ref,
                    "work_item_status": w["status"],
                    "queue_name": w["queue"],
                    "message": w["message"],
                    "agent_action": "Report status to caller."
                }

        return {
            "status": "not_found",
            "message": f"No work item found for {ref}.",
            "agent_action": "Inquire if caller has additional details or route to Investor Services."
        }
    except Exception as e:
        return {
            "status": "error",
            "message": str(e),
            "agent_action": "Route to Technical Support using escalate_interaction."
        }
