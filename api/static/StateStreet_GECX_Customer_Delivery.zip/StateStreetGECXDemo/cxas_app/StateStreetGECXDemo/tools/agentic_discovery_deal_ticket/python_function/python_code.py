"""Tool for discovering deals via non-monetary clues."""

def agentic_discovery_deal_ticket(account_no: str = "", txn_type: str = "", fund_code: str = "", date_str: str = "", amount_str: str = "") -> dict:
    """Searches for trades by non-monetary clues with 2-clue privacy gate.

    Args:
        account_no: Authenticated investor account number.
        txn_type: Transaction type (Subscription/Redemption).
        fund_code: Fund identifier or name.
        date_str: Trade or order date.
        amount_str: Approximate dollar amount.

    Returns:
        dict: Candidate trades or privacy gate rejection and agent_action.
    """
    try:
        clues = []
        if txn_type: clues.append("txn_type")
        if fund_code: clues.append("fund_code")
        if date_str: clues.append("date_str")

        # Privacy gate: Amount alone is strictly rejected
        if amount_str and len(clues) == 0:
            return {
                "status": "privacy_gate_rejected",
                "message": "Amount alone is insufficient to search transactions under privacy regulations.",
                "agent_action": "Prompt caller for transaction type, date, or fund name."
            }

        if len(clues) < 2:
            return {
                "status": "insufficient_clues",
                "message": "At least two corroborating clues are required for deal discovery.",
                "agent_action": "Request additional details such as transaction date or fund name."
            }

        # Return masked candidate
        return {
            "status": "candidates_found",
            "count": 1,
            "candidates": [
                {
                    "masked_trade_ref": "***5102",
                    "transaction_type": txn_type or "Subscription",
                    "fund_name": "Global Growth Class A",
                    "trade_date": date_str or "2026-09-18",
                    "masked_amount": "$500,***"
                }
            ],
            "agent_action": "Confirm candidate match with caller before disclosing full details."
        }
    except Exception as e:
        return {
            "status": "error",
            "message": str(e),
            "agent_action": "Route to Technical Support using escalate_interaction."
        }
