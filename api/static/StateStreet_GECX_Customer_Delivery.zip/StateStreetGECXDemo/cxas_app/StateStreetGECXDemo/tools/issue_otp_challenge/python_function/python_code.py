"""Tool for issuing MFA OTP challenges."""

def issue_otp_challenge(account_no: str = "", channel: str = "chat", target_contact: str = "") -> dict:
    """Issues a 6-digit MFA OTP challenge via Email or SMS.

    Args:
        account_no: Investor account number.
        channel: Delivery channel (chat -> email, voice -> sms).
        target_contact: Masked contact address.

    Returns:
        dict: Challenge dispatch status and agent_action.
    """
    try:
        masked = target_contact or ("s.***@apexglobal.com" if channel == "chat" else "+1-***-***-0142")
        return {
            "status": "challenge_issued",
            "account_no": account_no,
            "channel": channel,
            "target_contact_masked": masked,
            "otp_length": 6,
            "validity_minutes": 5,
            "message": f"A 6-digit verification code has been sent to {masked}.",
            "agent_action": "Prompt the user to provide the 6-digit verification code received."
        }
    except Exception as e:
        return {
            "status": "error",
            "message": str(e),
            "agent_action": "Route to Technical Support using escalate_interaction."
        }
