"""Tool for checking bank reconciliation cash receipts."""

def search_bank_rec(account_no: str = "", trade_ref: str = "") -> dict:
    """Queries Bank Reconciliation system for cash receipt match status.

    Args:
        account_no: Investor account number.
        trade_ref: Unique trade reference ID.

    Returns:
        dict: Bank rec matching status, SUBNR flag, and agent_action.
    """
    try:
        ref = str(trade_ref).strip().upper()
        recs = {
            "TRD-5010": {"bank_rec_status": "Matched", "subnr": "No", "cash_received": 2000000.00, "rec_date": "2026-09-18"},
            "TRD-5011": {"bank_rec_status": "Unmatched", "subnr": "No", "cash_received": 0.0, "rec_date": "2026-09-21"},
            "TRD-5012": {"bank_rec_status": "Unmatched", "subnr": "Yes", "cash_received": 0.0, "rec_date": "2026-09-21", "sd_plus_days": 1}
        }

        if ref in recs:
            r = recs[ref]
            return {
                "status": "found",
                "trade_ref": ref,
                "bank_rec_status": r["bank_rec_status"],
                "subnr": r["subnr"],
                "cash_received_amount": r["cash_received"],
                "agent_action": "If Matched report monies received; if Unmatched and SUBNR:Yes escalate to Cash Management."
            }

        return {
            "status": "not_found",
            "message": f"No bank rec record found for {ref}.",
            "agent_action": "Confirm trade settlement date or escalate to Cash Management."
        }
    except Exception as e:
        return {
            "status": "error",
            "message": str(e),
            "agent_action": "Route to Technical Support using escalate_interaction."
        }
