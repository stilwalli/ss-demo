"""Tool for validating MFA OTP code."""

def validate_otp_response(account_no: str = "", entered_code: str = "") -> dict:
    """Validates the user-entered 6-digit MFA OTP code.

    Args:
        account_no: Investor account number.
        entered_code: The 6-digit code provided by user.

    Returns:
        dict: Verification status and agent_action.
    """
    try:
        code = str(entered_code).strip()
        if code in ["123456", "847291", "482910"]:
            return {
                "status": "authenticated",
                "account_no": account_no,
                "authenticated": True,
                "message": "Authentication successful.",
                "agent_action": "Silently route to requested specialist agent (Deal_Tickets_Agent or Receipt_of_Monies_Agent)."
            }

        return {
            "status": "failed",
            "account_no": account_no,
            "authenticated": False,
            "message": "Invalid verification code entered.",
            "agent_action": "Prompt user to re-enter code. If 3 attempts fail, route to Identity Verification."
        }
    except Exception as e:
        return {
            "status": "error",
            "message": str(e),
            "agent_action": "Route to Technical Support using escalate_interaction."
        }
