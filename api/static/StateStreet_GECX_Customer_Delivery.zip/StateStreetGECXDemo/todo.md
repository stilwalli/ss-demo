# Build Steps (todo.md)

- [x] 1. Gather requirements (gate 1)
- [x] 2. TDD + user approval (gate 2)
- [ ] 3. Scaffold app (gate 3)
- [ ] 4. Lint clean (gate 4)
- [ ] 5. Generate evals — one eval-writer dispatch per type (gate 5)
- [ ] 6. Push + verify (gate 6)
