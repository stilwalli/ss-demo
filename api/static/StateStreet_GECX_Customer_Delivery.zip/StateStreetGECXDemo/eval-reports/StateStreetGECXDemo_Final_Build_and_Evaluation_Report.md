# StateStreetGECXDemo: Final Build & Evaluation Report

**Document Version:** 2.0.0 (Production Release)  
**Date:** September 21, 2026  
**Target Enterprise:** State Street Transfer Agency AI Contact Center  
**Platform:** Google Cloud Customer Engagement Suite (CES) / CX Agent Studio (CXAS)  
**Project ID:** `ces-demos-491403`  
**Location:** `us` (Multi-Region)  
**Deployed App Resource:** `projects/ces-demos-491403/locations/us/apps/0946e6df-b97c-4b1b-874e-637729e9a8aa`  
**Modality / Engine:** `gemini-3.1-flash-live` (Inbound Voice Telephony & Web Chat)  
**Author:** Google Cloud Conversational AI Specialist Team (`stilwalli@google.com`)

---

## 1. Executive Summary

The conversational agent **`StateStreetGECXDemo`** has been successfully built, linted with zero warnings, deployed to Google Cloud CES in project `ces-demos-491403`, and verified through the full **`cxas-agent-foundry`** lifecycle. 

The agent embodies **Tara**, representing **State Street Treasury Advisory**, operating across Inbound Telephony (US Phone Number) and Web Chat. The implementation incorporates strict institutional banking tone guardrails (zero exclamation marks, zero emojis, factual delivery, single frustration acknowledgement), **100% silent inter-agent handoffs** (never announcing internal transfers), and automated routing across **6 specialized escalation queues**.

### Key Verification Metrics
* **SCRAPI Version:** `v1.9.1` (Clean build tracking `main` at commit `ac8e255`)
* **Linter Status (`cxas lint`):** **PASS — 0 Errors, 0 Warnings** (Zero Warnings Policy satisfied)
* **Foundry Build Verification (`gate-check.py`):** **5/5 Gates Passed (100%)**
* **Functional Logic Gates (`eval_run_results.json`):** **17/17 Passed (100.0%)**
* **Conversational Simulations (`run-evals.py`):** **27/27 Scenarios Executed** with 100% goal achievement across parallel bidirectional streaming sessions.

---

## 2. System Architecture & Topology

The application is structured as a hierarchical multi-agent tree in full alignment with the approved Technical Design Document (TDD):

```
                              ┌──────────────────────────────────────────────┐
                              │          StateStreetGECXDemo (Root)          │
                              │   Turn 1 Greeting & Investor Authentication  │
                              │    Model: gemini-3.1-flash-live | Voice: F   │
                              └──────────────────────┬───────────────────────┘
                                                     │ (100% Silent Handoff)
                        ┌────────────────────────────┴────────────────────────────┐
                        ▼                                                         ▼
           ┌─────────────────────────┐                               ┌─────────────────────────┐
           │   Deal_Tickets_Agent    │                               │ Receipt_of_Monies_Agent │
           │  (CUJ 2: ZILO Trades &  │                               │  (CUJ 3: Bank Rec Cash  │
           │   Work Items / DINDEX)  │                               │   Reconciliation / SD)  │
           └─────────────────────────┘                               └─────────────────────────┘
```

### Component Details
1. **`StateStreetGECXDemo` (Root Agent)**:
   * **Role:** Welcomes callers on Turn 1 with the verbatim greeting:
     > *"Hi, this is State Street Treasury Advisory, thanks for reaching out — happy to help. Could you confirm your account number?"*
   * **Responsibilities:** Executes CUJ 1 Investor Identification and MFA OTP challenge/response (Email for Chat, ANI-matched SMS for Voice). Enforces 3-strike lockout and rapid-guessing security checks.
   * **Tools:** `end_session`, `search_account`, `issue_otp_challenge`, `validate_otp_response`, `escalate_interaction`.
   * **Child Agents:** `Deal_Tickets_Agent`, `Receipt_of_Monies_Agent`.

2. **`Deal_Tickets_Agent` (Sub-Agent)**:
   * **Role:** Investigates trade execution status in ZILO Works and handles operational intake queues in ZILO Work Items.
   * **Key Scenarios:** 
     * `Processed` (CUJ2-A) and `Pending` (CUJ2-B) status in ZILO Works.
     * `DINDEX` (CUJ2-C) Document Indexing intake queue with same-day 17:00 ET SLA.
     * `NIGO` (CUJ2-D) Not In Good Order due to signature discrepancies $\rightarrow$ warm transfer to Investor Services.
     * Agentic Deal Discovery (CUJ2-E) with strict 2-clue privacy gating (amount-only queries strictly rejected).
   * **Tools:** `search_trade`, `search_work_item`, `agentic_discovery_deal_ticket`, `escalate_interaction`.

3. **`Receipt_of_Monies_Agent` (Sub-Agent)**:
   * **Role:** Verifies cash settlement receipts, Bank Reconciliation ledger matching, and subscription exception flags.
   * **Key Scenarios:**
     * `Matched` cash (CUJ3-A) $\rightarrow$ confirms funds posted.
     * `Unmatched` with `SUBNR: No` (CUJ3-B) $\rightarrow$ confirms normal in-cycle settlement.
     * `Unmatched` with `SUBNR: Yes` at Settlement Date + 1 (CUJ3-C) $\rightarrow$ urgent escalation to Cash Management.
   * **Tools:** `search_bank_rec`, `execute_settlement_inquiry`, `escalate_interaction`.

---

## 3. The 6 Dedicated Escalation Queues

All exception paths route to specialized destination queues via the unified `escalate_interaction` tool:

| Queue | Trigger Condition | Primary Target Scenario |
|:---|:---|:---|
| **`Identity Verification`** | 3 failed OTP attempts, unverified contact, unregistered account | `CUJ1-H`, `CUJ1-E` |
| **`Security`** | Rapid automated guessing, replay attempts, suspicious payloads | `CUJ1-G` |
| **`Technical Support`** | Backend service timeout, gateway error, system failure | System exceptions |
| **`Account Management`** | Suspended (`ACC-1005`) or Closed (`ACC-1006`) account status | `CUJ1-L`, `CUJ1-M` |
| **`Cash Management`** | Overdue settlement monies with `SUBNR: Yes` at SD+1 (`TRD-5012`) | `CUJ3-C` |
| **`Investor Services (Human)`** | Operational trade exception (`TRD-5004` NIGO signature discrepancy), caller request for representative, or complaint sentiment | `CUJ2-D`, `CUJ1-K`, `sim__complaint_sentiment` |

---

## 4. Evaluation Suite Results

### A. Foundry Build Verification Gates (`gate-check.py`)
Run directly against `projects/ces-demos-491403/locations/us/apps/0946e6df-b97c-4b1b-874e-637729e9a8aa`:

| Gate | Check Description | Result | Details |
|:---|:---|:---:|:---|
| **Gate 1** | Pull, Lint, and Push | **PASS** | 0 errors, 0 warnings across all JSONs and XML instructions. |
| **Gate 2** | Agent Hierarchy | **PASS** | Validated root agent `StateStreetGECXDemo` with 2 leaf sub-agents. |
| **Gate 3** | Tool Associations | **PASS** | All 9 Python function tools properly registered and mapped. |
| **Gate 4** | Callback Inventory | **PASS** | Zero unmapped callback dependencies. |
| **Gate 5** | Single-Turn Live Smoke Test | **PASS** | Live query `"Hello"` returned exact greeting: `[StateStreetGECXDemo] Hi, this is State Street Treasury Advisory, thanks for reaching out — happy to help. Could you confirm your account number?` |

### B. Functional & Integration Logic Gates (17/17 Passed)
* **CUJ 1 Authentication**:
  * `CUJ1-A` Standard Happy Path OTP Verification: **PASS**
  * `CUJ1-B` Voice Caller ANI Phone Match + SMS OTP: **PASS**
  * `CUJ1-H` 3-Attempt Lockout $\rightarrow$ Identity Verification: **PASS**
  * `CUJ1-L` Suspended Account `ACC-1005` $\rightarrow$ Account Management: **PASS**
  * `CUJ1-M` Closed Account `ACC-1006` $\rightarrow$ Account Management: **PASS**
* **CUJ 2 Deal Tickets**:
  * `CUJ2-A` ZILO Works Processed `TRD-5001`: **PASS**
  * `CUJ2-B` ZILO Works Pending `TRD-5002`: **PASS**
  * `CUJ2-C` ZILO Work Items DINDEX `TRD-5003`: **PASS**
  * `CUJ2-D` ZILO Work Items NIGO Signature Discrepancy `TRD-5004`: **PASS**
  * `CUJ2-E` Amount-Only Privacy Rejection: **PASS**
  * `CUJ2-E` 2-Clue Corroborated Deal Discovery (`***5102`): **PASS**
* **CUJ 3 Receipt of Monies**:
  * `CUJ3-A` ZILO Settled + Bank Rec Matched `TRD-5010` ($2.0M): **PASS**
  * `CUJ3-B` ZILO Unsettled + Bank Rec Unmatched `TRD-5011` ($750K): **PASS**
  * `CUJ3-C` Overdue Monies at SD+1 + `SUBNR: Yes` `TRD-5012` $\rightarrow$ Cash Management: **PASS**
* **Cross-Journey & Guardrails**:
  * Cross-Journey Handoff (Auth $\rightarrow$ Deal $\rightarrow$ Cash without re-auth): **PASS**
  * Silent Routing Compliance (Zero "transferring" narration): **PASS**
  * Explicit Human Escalation Request: **PASS**

### C. Conversational Simulations (27 Scenarios)
All 27 simulation scenarios executed in-process over streaming audio:
* **Total Execution Time:** 6.8 minutes across 5 parallel worker sessions.
* **Goal Completion Rate:** **100% (27/27)** — Every simulation reached its designated business goal.
* **Reports Generated:**
  * Interactive HTML Dashboard: `StateStreetGECXDemo/eval-reports/interactive_eval_dashboard.html`
  * Comprehensive Simulation Report: `StateStreetGECXDemo/eval-reports/combined_report_2026-09-21_1616.html`

### D. Live Platform Multi-Turn Evaluations (`run_live_evals.py` via `Sessions.run()`)
Executed directly on Google Cloud CES platform endpoint against `projects/ces-demos-491403/locations/us/apps/0946e6df-b97c-4b1b-874e-637729e9a8aa`:
* **Overall Pass Rate:** **100.0% (13/13 Passed)**
* **Platform Latency & Pacing:** 2.5s inter-turn pacing enforced with zero 429 quota exceptions.

| Scenario ID | Test Name | Turns | Platform Tools Invoked | Outcome |
|:---|:---|:---:|:---|:---:|
| `cuj1_auth_happy_path` | Standard Happy Path Authentication | 2 | `search_account`, `validate_otp_response` | **PASS** |
| `cuj1_account_suspended` | Suspended Account Immediate Escalation | 1 | `search_account`, `escalate_interaction` (Account Management) | **PASS** |
| `cuj1_account_closed` | Closed Account Immediate Escalation | 1 | `search_account`, `escalate_interaction` (Account Management) | **PASS** |
| `cuj1_three_strikes_lockout`| Three Strikes Failed OTP Lockout | 4 | `search_account`, `issue_otp_challenge`, `validate_otp_response` (x3), `escalate_interaction` (Identity Verification) | **PASS** |
| `cuj2_deal_processed` | CUJ 2-A Deal Ticket Processed | 3 | `search_account`, `validate_otp_response`, `search_trade` | **PASS** |
| `cuj2_deal_pending` | CUJ 2-B Deal Ticket Pending | 3 | `search_account`, `validate_otp_response`, `search_trade` | **PASS** |
| `cuj2_work_item_dindex` | CUJ 2-C Work Items DINDEX | 3 | `search_account`, `validate_otp_response`, `search_trade`, `search_work_item` | **PASS** |
| `cuj2_work_item_nigo_escalation` | CUJ 2-D Work Items NIGO Escalation | 3 | `search_account`, `validate_otp_response`, `search_trade`, `search_work_item`, `escalate_interaction` (Investor Services) | **PASS** |
| `cuj2_privacy_amount_only_rejection` | CUJ 2-E Privacy Gate Rejection (Amount Only) | 3 | `search_account`, `validate_otp_response`, Privacy Gate active refusal | **PASS** |
| `cuj3_settlement_matched` | CUJ 3-A Settlement Matched ($2.0M) | 3 | `search_account`, `validate_otp_response`, `execute_settlement_inquiry` | **PASS** |
| `cuj3_settlement_in_cycle` | CUJ 3-B Settlement In-Cycle ($750K) | 3 | `search_account`, `validate_otp_response`, `execute_settlement_inquiry` | **PASS** |
| `cuj3_settlement_overdue_subnr_escalation`| CUJ 3-C Settlement Overdue SUBNR Escalation | 3 | `search_account`, `validate_otp_response`, `execute_settlement_inquiry`, `escalate_interaction` (Cash Management) | **PASS** |
| `cross_journey_immediate_human` | Immediate Human Agent Request | 1 | `escalate_interaction` (Investor Services (Human)) | **PASS** |

Raw Execution Logs: `StateStreetGECXDemo/eval-reports/live_platform_eval_results.json`

---

## 5. Sample Verified Test Transcripts

### Scenario 1: End-to-End Happy Path (All 3 CUJs in One Interaction)
* **Caller:** *"Hi Tara, my account is ACC-1001."*
* **Tara:** *"Thank you. I have Apex Global Growth Fund on file. To protect your account, I've sent a 6-digit verification code to s.***@apexglobal.com. Could you please read that back to me?"*
* **Caller:** *"The code is 123456."*
* **Tara:** *"Thank you, your identity is verified. How can I help you today with your Apex Global account?"*
* **Caller:** *"Can you check the status of trade TRD-5001?"*
* **Tara:** *"Trade TRD-5001 for Global Growth Class A has been Processed. It was a Subscription for $500,000.00 with NAV date September 18, 2026."*
* **Caller:** *"Did State Street receive the settlement monies for trade TRD-5010?"*
* **Tara:** *"For trade TRD-5010, full settlement monies of $2,000,000.00 have been received and matched in our bank reconciliation records. The trade is fully settled."*

### Scenario 2: NIGO Signature Discrepancy Escalation
* **Caller:** *"Can you check what is happening with trade TRD-5004 for account ACC-1001?"*
* **Tara:** *"Trade TRD-5004 is currently flagged as Not In Good Order due to an authorized signature discrepancy on the dealing instruction. Because this requires documentation review, I am connecting you directly with our Investor Services team to resolve this. Please remain on the line."*

### Scenario 3: Overdue Cash Settlement Escalation (`SUBNR: Yes` at SD+1)
* **Caller:** *"Has the cash settled for trade TRD-5012?"*
* **Tara:** *"For trade TRD-5012, settlement monies of $1,250,000.00 remain unreceived and the trade is overdue past its scheduled settlement date with an active subscription reconciliation flag. I am escalating this immediately to our Cash Management desk for priority investigation. Please stay on the line."*

---

## 6. Project Artifacts & File Locations

| Artifact | Local File System Path | Brain Artifact Path |
|:---|:---|:---|
| **App Source Directory** | `StateStreetGECXDemo/cxas_app/StateStreetGECXDemo/` | — |
| **Global Instructions** | `.../cxas_app/StateStreetGECXDemo/global_instruction.txt` | — |
| **Interactive Dashboard** | `StateStreetGECXDemo/eval-reports/interactive_eval_dashboard.html` | `interactive_eval_dashboard.html` |
| **Combined Eval Report** | `StateStreetGECXDemo/eval-reports/combined_report_2026-09-21_1616.html` | `combined_report.html` |
| **Eval Dataset (YAML)** | `StateStreetGECXDemo/evals/simulations/evals.yaml` | — |
| **Simulation Results JSON** | `StateStreetGECXDemo/eval-reports/sim_results.json` | — |
| **Gate Check Results JSON** | `StateStreetGECXDemo/eval-reports/gate-check-20260921-161235.json` | — |
