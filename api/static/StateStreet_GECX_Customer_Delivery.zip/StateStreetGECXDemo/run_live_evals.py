#!/usr/bin/env python3
"""Execute live multi-turn evaluations directly against the deployed CES agent."""

import os
import json
import uuid
from cxas_scrapi.core.sessions import Sessions

app_name = "projects/gcex-contact-center-508117/locations/us/apps/954f9664-9865-4fdc-9ced-751589097442"
sessions = Sessions(app_name=app_name)

test_scenarios = [
  {
    "id": "cuj1_auth_happy_path",
    "name": "Standard Happy Path Authentication",
    "dialog": [
      ("My account number is ACC-1001", ["search_account", "issue_otp_challenge"]),
      ("My code is 123456", ["validate_otp_response"])
    ]
  },
  {
    "id": "cuj1_auth_acc1003_atlas",
    "name": "Atlas Global (ACC-1003) Authentication",
    "dialog": [
      ("My account number is ACC-1003", ["search_account", "issue_otp_challenge"]),
      ("123456", ["validate_otp_response"])
    ]
  },
  {
    "id": "cuj1_auth_acc1004_ironclad",
    "name": "Ironclad Holdings (ACC-1004) Authentication Challenge",
    "dialog": [
      ("My account number is ACC-1004", ["search_account", "issue_otp_challenge"])
    ]
  },
  {
    "id": "cuj1_account_suspended",
    "name": "Suspended Account Immediate Escalation",
    "dialog": [
      ("My account number is ACC-1005", ["search_account", "escalate_interaction"])
    ]
  },
  {
    "id": "cuj1_account_closed",
    "name": "Closed Account Immediate Escalation",
    "dialog": [
      ("My account number is ACC-1006", ["search_account", "escalate_interaction"])
    ]
  },
  {
    "id": "cuj1_three_strikes_lockout",
    "name": "Three Strikes Failed OTP Lockout",
    "dialog": [
      ("My account is ACC-1001", ["search_account"]),
      ("Code 000000", ["validate_otp_response"]),
      ("Code 111111", ["validate_otp_response"]),
      ("Code 222222", ["validate_otp_response", "escalate_interaction"])
    ]
  },
  {
    "id": "cuj2_deal_processed",
    "name": "CUJ 2-A Deal Ticket Processed",
    "dialog": [
      ("My account is ACC-1001", []),
      ("123456", []),
      ("Check status of trade TRD-5001", ["search_trade"])
    ]
  },
  {
    "id": "cuj2_deal_pending",
    "name": "CUJ 2-B Deal Ticket Pending",
    "dialog": [
      ("My account is ACC-1001", []),
      ("123456", []),
      ("Check trade TRD-5002", ["search_trade"])
    ]
  },
  {
    "id": "cuj2_work_item_dindex",
    "name": "CUJ 2-C Work Items DINDEX",
    "dialog": [
      ("My account is ACC-1001", []),
      ("123456", []),
      ("Check trade TRD-5003", ["search_work_item"])
    ]
  },
  {
    "id": "cuj2_work_item_nigo_escalation",
    "name": "CUJ 2-D Work Items NIGO Signature Discrepancy",
    "dialog": [
      ("My account is ACC-1001", []),
      ("123456", []),
      ("Check trade TRD-5004", ["search_work_item", "escalate_interaction"])
    ]
  },
  {
    "id": "cuj2_privacy_amount_only_rejection",
    "name": "CUJ 2-E Privacy Gate Rejection (Amount Only)",
    "dialog": [
      ("My account is ACC-1001", []),
      ("123456", []),
      ("I wired $500,000, can you find my trade?", ["agentic_discovery_deal_ticket"])
    ]
  },
  {
    "id": "cuj3_settlement_matched",
    "name": "CUJ 3-A Settlement Matched ($2.0M)",
    "dialog": [
      ("My account is ACC-1001", []),
      ("123456", []),
      ("Did monies settle for trade TRD-5010?", ["execute_settlement_inquiry"])
    ]
  },
  {
    "id": "cuj3_settlement_in_cycle",
    "name": "CUJ 3-B Settlement In-Cycle ($750K)",
    "dialog": [
      ("My account is ACC-1001", []),
      ("123456", []),
      ("Has cash settled for trade TRD-5011?", ["execute_settlement_inquiry"])
    ]
  },
  {
    "id": "cuj3_settlement_overdue_subnr_escalation",
    "name": "CUJ 3-C Settlement Overdue SUBNR Yes Escalation",
    "dialog": [
      ("My account is ACC-1001", []),
      ("123456", []),
      ("Check cash settlement for trade TRD-5012", ["execute_settlement_inquiry", "escalate_interaction"])
    ]
  },
  {
    "id": "cross_journey_immediate_human",
    "name": "Immediate Human Agent Request",
    "dialog": [
      ("I want to speak with a representative immediately", ["escalate_interaction"])
    ]
  }
]

results = []
print(f"Executing {len(test_scenarios)} live scenarios on platform...")

for s in test_scenarios:
    s_id = s["id"]
    sid = f"eval-{s_id}-{uuid.uuid4().hex[:6]}"
    transcript = []
    all_passed = True
    
    for turn_idx, (user_text, expected_tools) in enumerate(s["dialog"], 1):
        try:
            import time
            time.sleep(2.5)
            resp = sessions.run(session_id=sid, text=user_text)
            sessions.parse_result(resp)
            transcript.append({"turn": turn_idx, "user": user_text, "status": "ok"})
        except Exception as e:
            all_passed = False
            transcript.append({"turn": turn_idx, "user": user_text, "error": str(e)})
            break
            
    import time
    time.sleep(2.0)
    status_str = "PASS" if all_passed else "FAIL"
    print(f"[{status_str}] {s['name']} ({len(transcript)} turns)")
    results.append({
        "id": s["id"],
        "name": s["name"],
        "passed": all_passed,
        "turns": len(transcript),
        "transcript": transcript
    })

output_dir = "/usr/local/google/home/stilwalli/mywork/StateStreetGECXDemo/eval-reports"
os.makedirs(output_dir, exist_ok=True)
output_path = os.path.join(output_dir, "live_platform_eval_results.json")
with open(output_path, "w") as f:
    json.dump({
        "total": len(results),
        "passed": sum(1 for r in results if r["passed"]),
        "pass_rate": f"{(sum(1 for r in results if r['passed']) / len(results)) * 100:.1f}%",
        "scenarios": results
    }, f, indent=2)

print(f"\n============================================================")
print(f"FINAL LIVE PLATFORM RESULTS: {sum(1 for r in results if r['passed'])}/{len(results)} passed ({(sum(1 for r in results if r['passed']) / len(results)) * 100:.1f}%)")
print(f"Results written to: {output_path}")
print(f"============================================================")
